import { useState } from 'react';
import Header from './components/Header';
import BottomNav from './components/BottomNav';
import HomePage from './components/HomePage';
import TasksPage from './components/TasksPage';
import PostTaskPage from './components/PostTaskPage';
import MessagesPage from './components/MessagesPage';
import ProfilePage from './components/ProfilePage';

const pages: Record<string, React.FC> = {
  home: HomePage,
  tasks: TasksPage,
  post: PostTaskPage,
  messages: MessagesPage,
  profile: ProfilePage,
};

export default function App() {
  const [activeTab, setActiveTab] = useState('home');
  const Page = pages[activeTab] || HomePage;

  return (
    <div className="min-h-screen bg-surface-dim">
      <Header />
      <main className="max-w-5xl mx-auto">
        <Page />
      </main>
      <BottomNav active={activeTab} onChange={setActiveTab} />
    </div>
  );
}
