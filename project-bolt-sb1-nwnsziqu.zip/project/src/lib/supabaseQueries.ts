import { supabase } from './supabaseClient';

// ── Connection test ──────────────────────────────────────────────
export async function testConnection(): Promise<{ ok: boolean; count?: number; error?: string }> {
  try {
    const { count, error } = await supabase
      .from('tasks')
      .select('*', { count: 'exact', head: true });

    if (error) {
      console.error('[Supabase] Connection test failed:', error.message);
      return { ok: false, error: error.message };
    }
    return { ok: true, count: count ?? 0 };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Unknown error';
    console.error('[Supabase] Connection test exception:', msg);
    return { ok: false, error: msg };
  }
}

// ── Tasks ────────────────────────────────────────────────────────
export async function fetchTasks(filters?: { status?: string; category?: string }) {
  try {
    let query = supabase
      .from('tasks')
      .select('*, profiles(display_name, avatar_url, rating)')
      .order('created_at', { ascending: false });

    if (filters?.status) query = query.eq('status', filters.status);
    if (filters?.category) query = query.eq('category', filters.category);

    const { data, error } = await query;
    if (error) {
      console.error('[Supabase] fetchTasks error:', error.message);
      return [];
    }
    return data ?? [];
  } catch (err) {
    console.error('[Supabase] fetchTasks exception:', err);
    return [];
  }
}

export async function fetchTaskById(taskId: string) {
  try {
    const { data, error } = await supabase
      .from('tasks')
      .select('*, profiles(display_name, avatar_url, rating, review_count)')
      .eq('id', taskId)
      .single();

    if (error) {
      console.error('[Supabase] fetchTaskById error:', error.message);
      return null;
    }
    return data;
  } catch (err) {
    console.error('[Supabase] fetchTaskById exception:', err);
    return null;
  }
}

export async function createTask(task: {
  title: string;
  description?: string;
  category?: string;
  budget?: number;
  location?: string;
  image_url?: string;
}) {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      console.error('[Supabase] createTask: no authenticated user');
      return null;
    }

    const { data, error } = await supabase
      .from('tasks')
      .insert({ ...task, user_id: user.id })
      .select()
      .single();

    if (error) {
      console.error('[Supabase] createTask error:', error.message);
      return null;
    }
    return data;
  } catch (err) {
    console.error('[Supabase] createTask exception:', err);
    return null;
  }
}

export async function updateTask(taskId: string, updates: Record<string, unknown>) {
  try {
    const { data, error } = await supabase
      .from('tasks')
      .update(updates)
      .eq('id', taskId)
      .select()
      .single();

    if (error) {
      console.error('[Supabase] updateTask error:', error.message);
      return null;
    }
    return data;
  } catch (err) {
    console.error('[Supabase] updateTask exception:', err);
    return null;
  }
}

export async function deleteTask(taskId: string) {
  try {
    const { error } = await supabase.from('tasks').delete().eq('id', taskId);
    if (error) {
      console.error('[Supabase] deleteTask error:', error.message);
      return false;
    }
    return true;
  } catch (err) {
    console.error('[Supabase] deleteTask exception:', err);
    return false;
  }
}

// ── Bids ─────────────────────────────────────────────────────────
export async function fetchBidsForTask(taskId: string) {
  try {
    const { data, error } = await supabase
      .from('bids')
      .select('*, profiles(display_name, avatar_url, rating)')
      .eq('task_id', taskId)
      .order('created_at', { ascending: true });

    if (error) {
      console.error('[Supabase] fetchBidsForTask error:', error.message);
      return [];
    }
    return data ?? [];
  } catch (err) {
    console.error('[Supabase] fetchBidsForTask exception:', err);
    return [];
  }
}

export async function createBid(taskId: string, amount: number, message?: string) {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;

    const { data, error } = await supabase
      .from('bids')
      .insert({ task_id: taskId, user_id: user.id, amount, message })
      .select()
      .single();

    if (error) {
      console.error('[Supabase] createBid error:', error.message);
      return null;
    }
    return data;
  } catch (err) {
    console.error('[Supabase] createBid exception:', err);
    return null;
  }
}

// ── Reviews ──────────────────────────────────────────────────────
export async function fetchReviewsForTask(taskId: string) {
  try {
    const { data, error } = await supabase
      .from('reviews')
      .select('*, profiles!reviews_reviewer_id_fkey(display_name, avatar_url)')
      .eq('task_id', taskId);

    if (error) {
      console.error('[Supabase] fetchReviewsForTask error:', error.message);
      return [];
    }
    return data ?? [];
  } catch (err) {
    console.error('[Supabase] fetchReviewsForTask exception:', err);
    return [];
  }
}

export async function createReview(taskId: string, revieweeId: string, rating: number, comment?: string) {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;

    const { data, error } = await supabase
      .from('reviews')
      .insert({ task_id: taskId, reviewer_id: user.id, reviewee_id: revieweeId, rating, comment })
      .select()
      .single();

    if (error) {
      console.error('[Supabase] createReview error:', error.message);
      return null;
    }
    return data;
  } catch (err) {
    console.error('[Supabase] createReview exception:', err);
    return null;
  }
}

// ── Messages ─────────────────────────────────────────────────────
export async function fetchConversations() {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return [];

    const { data, error } = await supabase
      .from('conversation_participants')
      .select('conversation_id, conversations(id, task_id, created_at)')
      .eq('user_id', user.id);

    if (error) {
      console.error('[Supabase] fetchConversations error:', error.message);
      return [];
    }
    return data ?? [];
  } catch (err) {
    console.error('[Supabase] fetchConversations exception:', err);
    return [];
  }
}

export async function fetchMessages(conversationId: string) {
  try {
    const { data, error } = await supabase
      .from('messages')
      .select('*')
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: true });

    if (error) {
      console.error('[Supabase] fetchMessages error:', error.message);
      return [];
    }
    return data ?? [];
  } catch (err) {
    console.error('[Supabase] fetchMessages exception:', err);
    return [];
  }
}

export async function sendMessage(conversationId: string, content: string) {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;

    const { data, error } = await supabase
      .from('messages')
      .insert({ conversation_id: conversationId, sender_id: user.id, content })
      .select()
      .single();

    if (error) {
      console.error('[Supabase] sendMessage error:', error.message);
      return null;
    }
    return data;
  } catch (err) {
    console.error('[Supabase] sendMessage exception:', err);
    return null;
  }
}

// ── Profile ──────────────────────────────────────────────────────
export async function fetchProfile(userId: string) {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (error) {
      console.error('[Supabase] fetchProfile error:', error.message);
      return null;
    }
    return data;
  } catch (err) {
    console.error('[Supabase] fetchProfile exception:', err);
    return null;
  }
}

export async function updateProfile(userId: string, updates: Record<string, unknown>) {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('user_id', userId)
      .select()
      .single();

    if (error) {
      console.error('[Supabase] updateProfile error:', error.message);
      return null;
    }
    return data;
  } catch (err) {
    console.error('[Supabase] updateProfile exception:', err);
    return null;
  }
}

// ── Notifications ────────────────────────────────────────────────
export async function fetchNotifications() {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return [];

    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('[Supabase] fetchNotifications error:', error.message);
      return [];
    }
    return data ?? [];
  } catch (err) {
    console.error('[Supabase] fetchNotifications exception:', err);
    return [];
  }
}

export async function markNotificationRead(notificationId: string) {
  try {
    const { error } = await supabase
      .from('notifications')
      .update({ read: true })
      .eq('id', notificationId);

    if (error) {
      console.error('[Supabase] markNotificationRead error:', error.message);
      return false;
    }
    return true;
  } catch (err) {
    console.error('[Supabase] markNotificationRead exception:', err);
    return false;
  }
}
