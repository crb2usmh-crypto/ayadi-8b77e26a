import { Bell, Search, Menu, X } from 'lucide-react';
import { useState } from 'react';
import ConnectionBadge from './ConnectionBadge';

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-surface/80 backdrop-blur-xl border-b border-outline">
      <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="lg:hidden p-2 rounded-xl hover:bg-slate-100 transition-colors"
          >
            {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center text-white font-extrabold text-lg shadow-md shadow-primary-200">
              أ
            </div>
            <div>
              <h1 className="text-lg font-extrabold text-on-surface leading-none">أيادي</h1>
              <p className="text-[10px] text-on-surface-variant leading-none mt-0.5">منصة المهام والخدمات</p>
            </div>
          </div>
        </div>

        <div className="hidden md:flex items-center gap-2 flex-1 max-w-md mx-4">
          <div className="relative w-full">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-on-surface-variant" />
            <input
              type="text"
              placeholder="ابحث عن مهمة..."
              className="w-full bg-surface-dim border border-outline rounded-xl pr-10 pl-4 py-2.5 text-sm placeholder:text-on-surface-variant/60 focus:outline-none focus:border-primary-400 focus:ring-2 focus:ring-primary-100 transition-all"
            />
          </div>
        </div>

        <div className="flex items-center gap-2">
          <ConnectionBadge />
          <button className="relative p-2.5 rounded-xl hover:bg-slate-100 transition-colors">
            <Bell className="w-5 h-5 text-on-surface-variant" />
            <span className="absolute top-1.5 left-1.5 w-2 h-2 bg-red-500 rounded-full" />
          </button>
        </div>
      </div>

      {/* Mobile search */}
      <div className="md:hidden px-4 pb-3">
        <div className="relative w-full">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-on-surface-variant" />
          <input
            type="text"
            placeholder="ابحث عن مهمة..."
            className="w-full bg-surface-dim border border-outline rounded-xl pr-10 pl-4 py-2.5 text-sm placeholder:text-on-surface-variant/60 focus:outline-none focus:border-primary-400 focus:ring-2 focus:ring-primary-100 transition-all"
          />
        </div>
      </div>
    </header>
  );
}
