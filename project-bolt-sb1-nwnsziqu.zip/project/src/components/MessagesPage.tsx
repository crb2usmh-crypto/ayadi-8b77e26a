import { MessageCircle } from 'lucide-react';

export default function MessagesPage() {
  return (
    <div className="pb-24 px-4 pt-4">
      <h2 className="text-xl font-extrabold text-on-surface mb-5">الرسائل</h2>
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <div className="w-16 h-16 rounded-2xl bg-primary-50 flex items-center justify-center mb-4">
          <MessageCircle className="w-8 h-8 text-primary-400" />
        </div>
        <p className="text-sm font-semibold text-on-surface mb-1">لا توجد محادثات</p>
        <p className="text-xs text-on-surface-variant">ستظهر المحادثات هنا عند تواصلك مع مستخدمين آخرين</p>
      </div>
    </div>
  );
}
