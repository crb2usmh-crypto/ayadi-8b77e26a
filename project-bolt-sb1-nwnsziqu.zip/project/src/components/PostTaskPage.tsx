import { useState } from 'react';
import { createTask } from '../lib/supabaseQueries';
import { Send, AlertTriangle, CheckCircle2 } from 'lucide-react';

const categories = ['تطوير ويب', 'تصميم', 'كتابة', 'تطوير تطبيقات', 'تسويق', 'ترجمة'];

export default function PostTaskPage() {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [budget, setBudget] = useState('');
  const [location, setLocation] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;

    setSubmitting(true);
    setError(null);
    setSuccess(false);

    try {
      const result = await createTask({
        title: title.trim(),
        description: description.trim() || undefined,
        category: category || undefined,
        budget: budget ? parseFloat(budget) : undefined,
        location: location.trim() || undefined,
      });

      if (result) {
        setSuccess(true);
        setTitle('');
        setDescription('');
        setCategory('');
        setBudget('');
        setLocation('');
      } else {
        setError('فشل إنشاء المهمة. تأكد من تسجيل الدخول.');
      }
    } catch (err) {
      console.error('[PostTask] exception:', err);
      setError('حدث خطأ غير متوقع');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="pb-24 px-4 pt-4">
      <h2 className="text-xl font-extrabold text-on-surface mb-5">إضافة مهمة جديدة</h2>

      {success && (
        <div className="mb-4 bg-accent-50 border border-accent-200 rounded-xl p-4 flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-accent-500 shrink-0" />
          <p className="text-sm font-semibold text-accent-700">تم إنشاء المهمة بنجاح!</p>
        </div>
      )}

      {error && (
        <div className="mb-4 bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
          <p className="text-sm text-red-600">{error}</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-semibold text-on-surface mb-1.5">عنوان المهمة *</label>
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="مثال: تصميم موقع متجر"
            className="w-full bg-surface border border-outline rounded-xl px-4 py-3 text-sm placeholder:text-on-surface-variant/50 focus:outline-none focus:border-primary-400 focus:ring-2 focus:ring-primary-100 transition-all"
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-on-surface mb-1.5">الوصف</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={4}
            placeholder="اشرح تفاصيل المهمة..."
            className="w-full bg-surface border border-outline rounded-xl px-4 py-3 text-sm placeholder:text-on-surface-variant/50 focus:outline-none focus:border-primary-400 focus:ring-2 focus:ring-primary-100 transition-all resize-none"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-semibold text-on-surface mb-1.5">التصنيف</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full bg-surface border border-outline rounded-xl px-4 py-3 text-sm text-on-surface focus:outline-none focus:border-primary-400 focus:ring-2 focus:ring-primary-100 transition-all appearance-none"
            >
              <option value="">اختر تصنيف</option>
              {categories.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-semibold text-on-surface mb-1.5">الميزانية (ر.س)</label>
            <input
              type="number"
              value={budget}
              onChange={(e) => setBudget(e.target.value)}
              placeholder="0"
              min="0"
              className="w-full bg-surface border border-outline rounded-xl px-4 py-3 text-sm placeholder:text-on-surface-variant/50 focus:outline-none focus:border-primary-400 focus:ring-2 focus:ring-primary-100 transition-all"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-on-surface mb-1.5">الموقع</label>
          <input
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="مثال: الرياض"
            className="w-full bg-surface border border-outline rounded-xl px-4 py-3 text-sm placeholder:text-on-surface-variant/50 focus:outline-none focus:border-primary-400 focus:ring-2 focus:ring-primary-100 transition-all"
          />
        </div>

        <button
          type="submit"
          disabled={submitting || !title.trim()}
          className="w-full bg-primary-600 text-white px-6 py-3.5 rounded-xl text-sm font-bold hover:bg-primary-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-lg shadow-primary-200"
        >
          {submitting ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : (
            <>
              <Send className="w-4 h-4" />
              نشر المهمة
            </>
          )}
        </button>
      </form>
    </div>
  );
}
