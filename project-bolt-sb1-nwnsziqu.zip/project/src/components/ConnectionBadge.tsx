import { useEffect, useState } from 'react';
import { testConnection } from '../lib/supabaseQueries';
import { Wifi, WifiOff, Loader2 } from 'lucide-react';

export default function ConnectionBadge() {
  const [status, setStatus] = useState<'loading' | 'connected' | 'error'>('loading');
  const [taskCount, setTaskCount] = useState<number>(0);
  const [errorMsg, setErrorMsg] = useState<string>('');

  useEffect(() => {
    let mounted = true;

    async function check() {
      const result = await testConnection();
      if (!mounted) return;

      if (result.ok) {
        setStatus('connected');
        setTaskCount(result.count ?? 0);
      } else {
        setStatus('error');
        setErrorMsg(result.error ?? 'فشل الاتصال');
      }
    }

    check();
    const interval = setInterval(check, 30000);
    return () => {
      mounted = false;
      clearInterval(interval);
    };
  }, []);

  return (
    <div className="flex items-center gap-2">
      {status === 'loading' && (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-on-surface-variant bg-slate-100 px-3 py-1.5 rounded-full">
          <Loader2 className="w-3.5 h-3.5 animate-spin" />
          جاري الاتصال...
        </span>
      )}
      {status === 'connected' && (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-accent-600 bg-accent-50 px-3 py-1.5 rounded-full border border-accent-200">
          <Wifi className="w-3.5 h-3.5" />
          متصل ({taskCount} مهمة)
        </span>
      )}
      {status === 'error' && (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-red-600 bg-red-50 px-3 py-1.5 rounded-full border border-red-200">
          <WifiOff className="w-3.5 h-3.5" />
          خطأ: {errorMsg}
        </span>
      )}
    </div>
  );
}
