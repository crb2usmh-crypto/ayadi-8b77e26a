import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import { fetchProfile } from '../lib/supabaseQueries';
import { User, LogIn, LogOut, Star, MapPin, Mail } from 'lucide-react';

export default function ProfilePage() {
  const [user, setUser] = useState<ReturnType<typeof supabase.auth.getUser> extends Promise<infer R> ? Awaited<R>['data']['user'] : null>(null);
  const [profile, setProfile] = useState<{ display_name: string | null; bio: string | null; rating: number | null; location: string | null; review_count: number | null } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUser();
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      if (session?.user) loadProfile(session.user.id);
      else setProfile(null);
    });
    return () => subscription.unsubscribe();
  }, []);

  async function loadUser() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      setUser(user);
      if (user) await loadProfile(user.id);
    } catch (err) {
      console.error('[Profile] loadUser error:', err);
    } finally {
      setLoading(false);
    }
  }

  async function loadProfile(userId: string) {
    const p = await fetchProfile(userId);
    setProfile(p);
  }

  async function handleSignOut() {
    await supabase.auth.signOut();
    setUser(null);
    setProfile(null);
  }

  if (loading) {
    return (
      <div className="pb-24 px-4 pt-4 flex items-center justify-center py-16">
        <div className="w-10 h-10 border-3 border-primary-200 border-t-primary-600 rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="pb-24 px-4 pt-4">
        <h2 className="text-xl font-extrabold text-on-surface mb-5">حسابي</h2>
        <div className="bg-surface rounded-2xl border border-outline p-6 text-center">
          <div className="w-16 h-16 rounded-2xl bg-primary-50 flex items-center justify-center mx-auto mb-4">
            <User className="w-8 h-8 text-primary-400" />
          </div>
          <p className="text-sm font-semibold text-on-surface mb-1">لم تسجل الدخول بعد</p>
          <p className="text-xs text-on-surface-variant mb-4">سجّل دخولك للوصول إلى حسابك وإدارة مهامك</p>
          <button className="inline-flex items-center gap-2 bg-primary-600 text-white px-6 py-3 rounded-xl text-sm font-bold hover:bg-primary-700 transition-colors shadow-lg shadow-primary-200">
            <LogIn className="w-4 h-4" />
            تسجيل الدخول
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="pb-24 px-4 pt-4">
      <h2 className="text-xl font-extrabold text-on-surface mb-5">حسابي</h2>
      <div className="bg-surface rounded-2xl border border-outline overflow-hidden">
        {/* Profile header */}
        <div className="bg-gradient-to-bl from-primary-500 to-primary-700 p-6 text-white">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center text-2xl font-extrabold">
              {profile?.display_name?.charAt(0) || user.email?.charAt(0) || 'م'}
            </div>
            <div>
              <h3 className="text-lg font-bold">{profile?.display_name || 'مستخدم'}</h3>
              <p className="text-primary-200 text-xs flex items-center gap-1">
                <Mail className="w-3 h-3" />
                {user.email}
              </p>
            </div>
          </div>
        </div>

        {/* Profile details */}
        <div className="p-5 space-y-4">
          {profile?.bio && (
            <p className="text-sm text-on-surface-variant leading-relaxed">{profile.bio}</p>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div className="bg-surface-dim rounded-xl p-3 text-center">
              <div className="flex items-center justify-center gap-1 text-warm-400 mb-1">
                <Star className="w-4 h-4 fill-current" />
                <span className="text-lg font-extrabold text-on-surface">{profile?.rating?.toFixed(1) || '0.0'}</span>
              </div>
              <p className="text-[10px] text-on-surface-variant">التقييم</p>
            </div>
            <div className="bg-surface-dim rounded-xl p-3 text-center">
              <span className="text-lg font-extrabold text-on-surface">{profile?.review_count || 0}</span>
              <p className="text-[10px] text-on-surface-variant">تقييم</p>
            </div>
          </div>

          {profile?.location && (
            <p className="text-xs text-on-surface-variant flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5" />
              {profile.location}
            </p>
          )}

          <button
            onClick={handleSignOut}
            className="w-full mt-2 bg-red-50 text-red-600 border border-red-200 px-4 py-3 rounded-xl text-sm font-semibold hover:bg-red-100 transition-colors flex items-center justify-center gap-2"
          >
            <LogOut className="w-4 h-4" />
            تسجيل الخروج
          </button>
        </div>
      </div>
    </div>
  );
}
