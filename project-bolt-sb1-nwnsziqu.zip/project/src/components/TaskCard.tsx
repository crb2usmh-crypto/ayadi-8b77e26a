import { MapPin, Clock, DollarSign, Tag } from 'lucide-react';

interface Task {
  id: string;
  title: string;
  description: string | null;
  category: string | null;
  budget: number | null;
  location: string | null;
  status: string;
  created_at: string;
  profiles?: { display_name: string | null; avatar_url: string | null; rating: number | null } | null;
}

const statusColors: Record<string, string> = {
  open: 'bg-accent-50 text-accent-600 border-accent-200',
  in_progress: 'bg-warm-50 text-warm-500 border-warm-200',
  completed: 'bg-primary-50 text-primary-600 border-primary-200',
  cancelled: 'bg-red-50 text-red-500 border-red-200',
};

const statusLabels: Record<string, string> = {
  open: 'مفتوحة',
  in_progress: 'قيد التنفيذ',
  completed: 'مكتملة',
  cancelled: 'ملغاة',
};

export default function TaskCard({ task }: { task: Task }) {
  const timeAgo = getTimeAgo(task.created_at);

  return (
    <div className="bg-surface rounded-2xl border border-outline p-5 hover:shadow-lg hover:border-primary-200 transition-all duration-300 cursor-pointer group">
      <div className="flex items-start justify-between gap-3 mb-3">
        <h3 className="text-base font-bold text-on-surface group-hover:text-primary-600 transition-colors line-clamp-2">
          {task.title}
        </h3>
        <span className={`shrink-0 text-[11px] font-semibold px-2.5 py-1 rounded-full border ${statusColors[task.status] || statusColors.open}`}>
          {statusLabels[task.status] || task.status}
        </span>
      </div>

      {task.description && (
        <p className="text-sm text-on-surface-variant mb-3 line-clamp-2 leading-relaxed">
          {task.description}
        </p>
      )}

      <div className="flex items-center gap-3 text-xs text-on-surface-variant mb-3">
        {task.category && (
          <span className="inline-flex items-center gap-1">
            <Tag className="w-3.5 h-3.5" />
            {task.category}
          </span>
        )}
        {task.location && (
          <span className="inline-flex items-center gap-1">
            <MapPin className="w-3.5 h-3.5" />
            {task.location}
          </span>
        )}
        <span className="inline-flex items-center gap-1">
          <Clock className="w-3.5 h-3.5" />
          {timeAgo}
        </span>
      </div>

      <div className="flex items-center justify-between pt-3 border-t border-outline">
        <div className="flex items-center gap-2">
          {task.profiles?.avatar_url ? (
            <img src={task.profiles.avatar_url} alt="" className="w-7 h-7 rounded-full object-cover" />
          ) : (
            <div className="w-7 h-7 rounded-full bg-primary-100 flex items-center justify-center text-primary-600 text-xs font-bold">
              {task.profiles?.display_name?.charAt(0) || '?'}
            </div>
          )}
          <span className="text-xs font-medium text-on-surface">{task.profiles?.display_name || 'مستخدم'}</span>
          {task.profiles?.rating != null && task.profiles.rating > 0 && (
            <span className="text-[11px] text-warm-400">({task.profiles.rating})</span>
          )}
        </div>
        {task.budget != null && (
          <span className="inline-flex items-center gap-1 text-sm font-bold text-primary-600">
            <DollarSign className="w-4 h-4" />
            {task.budget.toLocaleString('ar-SA')} ر.س
          </span>
        )}
      </div>
    </div>
  );
}

function getTimeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return mins <= 1 ? 'الآن' : `منذ ${mins} دقيقة`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `منذ ${hours} ساعة`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `منذ ${days} يوم`;
  return `منذ ${Math.floor(days / 7)} أسبوع`;
}
