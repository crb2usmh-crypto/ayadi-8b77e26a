import { Home, Briefcase, PlusCircle, MessageCircle, User } from 'lucide-react';

const tabs = [
  { id: 'home', label: 'الرئيسية', Icon: Home },
  { id: 'tasks', label: 'المهام', Icon: Briefcase },
  { id: 'post', label: 'أضف مهمة', Icon: PlusCircle, highlight: true },
  { id: 'messages', label: 'الرسائل', Icon: MessageCircle },
  { id: 'profile', label: 'حسابي', Icon: User },
];

interface BottomNavProps {
  active: string;
  onChange: (id: string) => void;
}

export default function BottomNav({ active, onChange }: BottomNavProps) {
  return (
    <nav className="fixed bottom-0 inset-x-0 z-50 bg-surface/90 backdrop-blur-xl border-t border-outline safe-area-pb">
      <div className="max-w-5xl mx-auto flex items-center justify-around h-16 px-2">
        {tabs.map(({ id, label, Icon, highlight }) => {
          const isActive = active === id;
          return (
            <button
              key={id}
              onClick={() => onChange(id)}
              className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition-all duration-200 ${
                highlight
                  ? isActive
                    ? 'text-primary-600'
                    : 'text-primary-400 hover:text-primary-500'
                  : isActive
                  ? 'text-primary-600'
                  : 'text-on-surface-variant hover:text-on-surface'
              }`}
            >
              <Icon className={`w-5 h-5 ${highlight && !isActive ? 'w-6 h-6' : ''}`} strokeWidth={isActive ? 2.5 : 1.8} />
              <span className={`text-[10px] font-semibold ${isActive ? 'text-primary-600' : ''}`}>
                {label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
