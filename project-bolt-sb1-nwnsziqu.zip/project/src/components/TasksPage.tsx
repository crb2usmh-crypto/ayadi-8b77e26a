import { useEffect, useState } from 'react';
import { fetchTasks } from '../lib/supabaseQueries';
import TaskCard from './TaskCard';
import { Filter, AlertTriangle } from 'lucide-react';

const statusFilters = [
  { id: 'all', label: 'الكل' },
  { id: 'open', label: 'مفتوحة' },
  { id: 'in_progress', label: 'قيد التنفيذ' },
  { id: 'completed', label: 'مكتملة' },
];

interface Task {
  id: string;
  title: string;
  description: string | null;
  category: string | null;
  budget: number | null;
  location: string | null;
  status: string;
  created_at: string;
  profiles?: { display_name: string | null; avatar_url: string | null; rating: number | null } | null;
}

export default function TasksPage() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeStatus, setActiveStatus] = useState('all');

  useEffect(() => {
    loadTasks();
  }, [activeStatus]);

  async function loadTasks() {
    setLoading(true);
    setError(null);
    try {
      const filters: { status?: string } = {};
      if (activeStatus !== 'all') filters.status = activeStatus;
      const data = await fetchTasks(filters);
      setTasks(data);
    } catch (err) {
      console.error('[TasksPage] loadTasks exception:', err);
      setError('حدث خطأ أثناء تحميل المهام');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="pb-24 px-4 pt-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-extrabold text-on-surface">المهام</h2>
        <Filter className="w-5 h-5 text-on-surface-variant" />
      </div>

      {/* Status filter */}
      <div className="flex gap-2 mb-5 overflow-x-auto scrollbar-hide">
        {statusFilters.map((sf) => (
          <button
            key={sf.id}
            onClick={() => setActiveStatus(sf.id)}
            className={`shrink-0 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              activeStatus === sf.id
                ? 'bg-primary-600 text-white shadow-md shadow-primary-200'
                : 'bg-surface border border-outline text-on-surface-variant hover:border-primary-300'
            }`}
          >
            {sf.label}
          </button>
        ))}
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-3 mb-4">
          <AlertTriangle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-bold text-red-700">خطأ في الاتصال</p>
            <p className="text-xs text-red-600 mt-0.5">{error}</p>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex flex-col items-center justify-center py-16">
          <div className="w-10 h-10 border-3 border-primary-200 border-t-primary-600 rounded-full animate-spin" />
          <p className="text-sm text-on-surface-variant mt-4">جاري التحميل...</p>
        </div>
      ) : tasks.length === 0 ? (
        <div className="text-center py-16">
          <p className="text-on-surface-variant text-sm">لا توجد مهام بهذا التصنيف</p>
        </div>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {tasks.map((task) => (
            <TaskCard key={task.id} task={task} />
          ))}
        </div>
      )}
    </div>
  );
}
