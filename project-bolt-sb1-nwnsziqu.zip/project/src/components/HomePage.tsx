import { useEffect, useState } from 'react';
import { fetchTasks, testConnection } from '../lib/supabaseQueries';
import TaskCard from './TaskCard';
import { TrendingUp, Zap, ArrowLeft, AlertTriangle } from 'lucide-react';

interface Task {
  id: string;
  title: string;
  description: string | null;
  category: string | null;
  budget: number | null;
  location: string | null;
  status: string;
  created_at: string;
  profiles?: { display_name: string | null; avatar_url: string | null; rating: number | null } | null;
}

const categories = ['الكل', 'تطوير ويب', 'تصميم', 'كتابة', 'تطوير تطبيقات', 'تسويق', 'ترجمة'];

export default function HomePage() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [taskCount, setTaskCount] = useState<number>(0);
  const [activeCategory, setActiveCategory] = useState('الكل');

  useEffect(() => {
    loadTasks();
    loadCount();
  }, [activeCategory]);

  async function loadCount() {
    const result = await testConnection();
    if (result.ok) setTaskCount(result.count ?? 0);
  }

  async function loadTasks() {
    setLoading(true);
    setError(null);
    try {
      const filters: { status?: string; category?: string } = {};
      if (activeCategory !== 'الكل') filters.category = activeCategory;
      const data = await fetchTasks(filters);
      setTasks(data);
    } catch (err) {
      console.error('[Home] loadTasks exception:', err);
      setError('حدث خطأ أثناء تحميل المهام');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="pb-24">
      {/* Hero banner */}
      <div className="relative overflow-hidden bg-gradient-to-bl from-primary-600 via-primary-700 to-primary-900 mx-4 mt-4 rounded-3xl p-6 text-white">
        <div className="absolute top-0 left-0 w-48 h-48 bg-white/10 rounded-full -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-32 h-32 bg-white/5 rounded-full translate-x-1/3 translate-y-1/3" />
        <div className="relative z-10">
          <p className="text-primary-200 text-sm font-medium mb-1">مرحباً بك في أيادي</p>
          <h2 className="text-2xl font-extrabold mb-1">اعثر على مهامك القادمة</h2>
          <p className="text-primary-200 text-sm mb-4">
            {taskCount > 0
              ? `يوجد حالياً ${taskCount} مهمة متاحة`
              : 'جاري تحميل المهام...'}
          </p>
          <button className="inline-flex items-center gap-2 bg-white text-primary-700 px-5 py-2.5 rounded-xl text-sm font-bold hover:bg-primary-50 transition-colors shadow-lg">
            تصفح المهام
            <ArrowLeft className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 mx-4 mt-5">
        <div className="bg-surface rounded-2xl border border-outline p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-accent-50 flex items-center justify-center">
            <TrendingUp className="w-5 h-5 text-accent-500" />
          </div>
          <div>
            <p className="text-xl font-extrabold text-on-surface">{taskCount}</p>
            <p className="text-[11px] text-on-surface-variant">مهمة متاحة</p>
          </div>
        </div>
        <div className="bg-surface rounded-2xl border border-outline p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-warm-50 flex items-center justify-center">
            <Zap className="w-5 h-5 text-warm-500" />
          </div>
          <div>
            <p className="text-xl font-extrabold text-on-surface">{tasks.filter(t => t.status === 'in_progress').length}</p>
            <p className="text-[11px] text-on-surface-variant">قيد التنفيذ</p>
          </div>
        </div>
      </div>

      {/* Error banner */}
      {error && (
        <div className="mx-4 mt-4 bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-bold text-red-700">خطأ في الاتصال بقاعدة البيانات</p>
            <p className="text-xs text-red-600 mt-0.5">{error}</p>
          </div>
        </div>
      )}

      {/* Category pills */}
      <div className="mt-5 px-4">
        <h3 className="text-sm font-bold text-on-surface mb-3">التصنيفات</h3>
        <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`shrink-0 px-4 py-2 rounded-xl text-xs font-semibold transition-all duration-200 ${
                activeCategory === cat
                  ? 'bg-primary-600 text-white shadow-md shadow-primary-200'
                  : 'bg-surface border border-outline text-on-surface-variant hover:border-primary-300 hover:text-primary-600'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Tasks list */}
      <div className="mt-5 px-4">
        <h3 className="text-sm font-bold text-on-surface mb-3">أحدث المهام</h3>
        {loading ? (
          <div className="flex flex-col items-center justify-center py-16">
            <div className="w-10 h-10 border-3 border-primary-200 border-t-primary-600 rounded-full animate-spin" />
            <p className="text-sm text-on-surface-variant mt-4">جاري تحميل المهام...</p>
          </div>
        ) : tasks.length === 0 && !error ? (
          <div className="text-center py-16">
            <p className="text-on-surface-variant text-sm">لا توجد مهام حالياً</p>
          </div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2">
            {tasks.map((task) => (
              <TaskCard key={task.id} task={task} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
