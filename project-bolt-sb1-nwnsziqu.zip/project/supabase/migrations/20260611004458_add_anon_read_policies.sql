
-- Allow unauthenticated users to read tasks and profiles (public browsing)
CREATE POLICY "anon_select_tasks" ON tasks FOR SELECT TO anon USING (true);
CREATE POLICY "anon_select_profiles" ON profiles FOR SELECT TO anon USING (true);
CREATE POLICY "anon_select_bids" ON bids FOR SELECT TO anon USING (true);
CREATE POLICY "anon_select_reviews" ON reviews FOR SELECT TO anon USING (true);
